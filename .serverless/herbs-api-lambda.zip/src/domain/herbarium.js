const { herbarium } = require('@herbsjs/herbarium')
module.exports = herbarium