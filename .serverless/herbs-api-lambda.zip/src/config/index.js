module.exports = {
  sqs: require('./sqs')
}